export  class Employee{
    public name : string ;
    public id : Number ;
    public city : string;
}